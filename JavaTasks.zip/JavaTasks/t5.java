// Task : 05 Create a 2d array of float having size 3*3. 
// Now apply the logic to make elements  to be store an other 3*3 array having transposition .  

import java.util.Scanner;
class t5{
	public static void main(String[] args){
    float[][] array1 = {{12,23,34},{45,56,67},{78,89,90}};
    float[][] transposedArray = new float[3][3];

  System.out.println("Original Matrix:");
   
 for(int i = 0; i<array1.length; i++){
      for(int j = 0; j<array1.length; j++){
         System.out.print(array1[i][j]+" ");
      }
    System.out.println();
    }


    for(int i = 0; i<array1.length; i++){
    	for(int j = 0; j<array1.length; j++){
    		transposedArray[j][i]=array1[i][j];
    	}
    }

    System.out.println("\nTransposed Matrix:");
    
     for(int i = 0; i<array1.length; i++){
      for(int j = 0; j<array1.length; j++){
         System.out.print(transposedArray[i][j]+" ");
      }
    System.out.println();
    }

	}
}