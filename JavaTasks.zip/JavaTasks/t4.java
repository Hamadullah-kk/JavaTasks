// Task 04: modify program 03. Calculate the no. of odds, even and prime digits of 4*4 matrix.
//  As values entered by user. 

import java.util.Scanner;
class t4{
 public static void main(String[] args){
 	Scanner input = new Scanner(System.in);
 	int[][] array = new int[4][4];
    int sum1 = 0;
    int sum = 0;
 	System.out.println("Enter Values of 2D array.");
 	for(int i = 0; i < array.length; i++){
 	   for(int j = 0; j < array.length; j++){
 	   	array[i][j] = input.nextInt();
 	   }
 	}
   
   for(int i = 0; i < array.length; i++){
      for(int j = 0; j < array.length; j++){
         if(array[i][j]%2==0){
            sum1+=array[i][j];
         }else{
            sum+=array[i][j];
         }
      }
   }

 	System.out.println("The sum of all Even numbers : "+sum1);
   System.out.println("The sum of all Odd numbers : "+sum);

 }
}
 	  