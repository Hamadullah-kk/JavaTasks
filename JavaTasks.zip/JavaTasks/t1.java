// Task : 01 Create a 2d Array of 2*5. and store 10 values Use any nested loop to print them.  

import java.util.Scanner;
class t1{
	public static void main(String[] args){
	int[][] array ={{1,3,5,7,9},
	               {11,13,15,17,19}};

	for(int i = 0; i < array.length; i++){
	   for(int j = 0; j < 5; j++){
	    System.out.print(array[i][j]+" ");
	   }
	   System.out.println();
	}               

	}
}