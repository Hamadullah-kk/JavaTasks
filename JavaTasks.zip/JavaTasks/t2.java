// Task : 02 Create 2d Array of character data type2*3. Ask user to store 6 
// symbols or letters into array.
// Your program must Display the ASCII codes of those symbol using nested 
// loop

import java.util.Scanner;

class t2{
    public static void main(String[] args) {
        char[][] array = new char[2][3];

    Scanner scanner = new Scanner(System.in);

    System.out.println("Enter 6 symbols or letters for the 2x3 character array:");

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            System.out.print("Enter character for position [" + i + "][" + j + "]: ");
            array[i][j] = scanner.next().charAt(0);
    }}

    System.out.println("\nASCII Codes of Entered Characters:");
    
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
         System.out.println("symbols: " + array[i][j] + " | ASCII Code: " + (int) array[i][j]); 
    }}

}
}
