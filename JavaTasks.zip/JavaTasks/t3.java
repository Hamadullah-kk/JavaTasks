//Task : 03 create a 2d array of size 4*4. 
//Ask any numbers from the user and store it in 2d array. 
//In last, your program must sum up all the diagonal values of that matrix values. 

import java.util.Scanner;
class t3{
 public static void main(String[] args){
 	Scanner input = new Scanner(System.in);
 	int[][] array = new int[4][4];
 	System.out.println("Enter Values of 2D array.");
 	for(int i = 0; i < array.length; i++){
 	   for(int j = 0; j < array.length; j++){
 	   	array[i][j] = input.nextInt();
 	   }
 	}
    int sum = 0;
    for(int i = 0; i < 4; i++){
 	   	sum += array[i][i];
 	}
 	System.out.println("The sum diagonal is : "+sum);

 }
}
 	  